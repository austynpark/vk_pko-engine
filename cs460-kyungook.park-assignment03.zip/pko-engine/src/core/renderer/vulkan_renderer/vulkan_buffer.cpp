#include "vulkan_buffer.h"

#include "vulkan_command_buffer.h"

void vulkan_buffer_create(
	vulkan_context* context,
	u64 buffer_size,
	VkBufferUsageFlags buffer_usage_flag,
	VmaMemoryUsage memory_usage_flag,
	VmaAllocationCreateFlags alloc_create_flag,
	vulkan_allocated_buffer* buffer
	) 
{
	VkBufferCreateInfo buffer_create_info{ VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO };
	buffer_create_info.size = buffer_size;
	buffer_create_info.usage = buffer_usage_flag;

	VmaAllocationCreateInfo alloc_create_info{};
	alloc_create_info.usage = memory_usage_flag;
	alloc_create_info.flags = alloc_create_flag;

	buffer->size = buffer_size;

	VK_CHECK(vmaCreateBuffer(
		context->vma_allocator,
		&buffer_create_info,
		&alloc_create_info,
		&buffer->handle,
		&buffer->allocation,
		nullptr
	));
}

void vulkan_buffer_copy(vulkan_context* context,
	vulkan_allocated_buffer* src_buffer,
	vulkan_allocated_buffer* dst_buffer,
	u64 size,
	u64 src_offset,
	u64 dst_offset
)
{
	vulkan_command one_time_submit;
	vulkan_command_pool_create(context, &one_time_submit, context->device_context.transfer_family.index);
	vulkan_command_buffer_allocate(context, &one_time_submit, true);

	VkBufferCopy buffer_copy{
		src_offset,// srcOffset
		dst_offset,// dstOffset
		size// size
	};

	vulkan_command_buffer_begin(&one_time_submit, VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT);
	vkCmdCopyBuffer(one_time_submit.buffer, src_buffer->handle, dst_buffer->handle, 1, &buffer_copy);
	vulkan_command_buffer_end(&one_time_submit);
	
	VkSubmitInfo submit_info = {};
	submit_info.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
	submit_info.commandBufferCount = 1;
	submit_info.pCommandBuffers = &one_time_submit.buffer;

	VK_CHECK(vkQueueSubmit(context->device_context.transfer_queue, 1, &submit_info, VK_NULL_HANDLE));
	vkQueueWaitIdle(context->device_context.transfer_queue);
	vulkan_command_pool_destroy(context, &one_time_submit);
}


void vulkan_buffer_destroy(vulkan_context* context, vulkan_allocated_buffer* buffer) {

	vmaDestroyBuffer(context->vma_allocator, buffer->handle, buffer->allocation);
}

void vulkan_buffer_upload(vulkan_context* context, vulkan_allocated_buffer* buffer, void* data, u32 data_size)
{
	void* copied_data;
	vmaMapMemory(context->vma_allocator, buffer->allocation, &copied_data);
	memcpy_s(copied_data, data_size, data, data_size);
	vmaUnmapMemory(context->vma_allocator, buffer->allocation);
}

u32 vulkan_uniform_buffer_pad_size(u32 min_ubo_alignment, u32 data_size)
{
	// Calculate required alignment based on minimum device offset alignment
	size_t alignedSize = data_size;
	if (min_ubo_alignment > 0) {
		alignedSize = (alignedSize + min_ubo_alignment - 1) & ~(min_ubo_alignment - 1);
	}
	return alignedSize;
}
